import os
import html
import random
import logging
from urllib.parse import quote

import requests
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
)
from telegram.constants import ParseMode
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ContextTypes, filters,
)

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("sormobot")

BOT_TOKEN = os.environ["BOT_TOKEN"]
ADMIN_ID = int(os.environ["ADMIN_ID"])
CHANNEL_ID = os.environ.get("CHANNEL_ID", "").strip()
CURSEFORGE_API_KEY = os.environ.get("CURSEFORGE_API_KEY", "").strip()

# CurseForge Minecraft game ID. API access requires a CurseForge API key.
CF_SEARCH_URL = "https://api.curseforge.com/v1/mods/search"
MINECRAFT_GAME_ID = 432

# Simple in-memory draft state. For a first version, avoid running multiple replicas.
DRAFTS = {}
WAITING_FOR_EDIT = set()

def is_admin(update: Update) -> bool:
    return bool(update.effective_user and update.effective_user.id == ADMIN_ID)

def clean(s: str) -> str:
    return html.escape(s or "")

def cf_search(query: str = "", page_size: int = 20):
    if not CURSEFORGE_API_KEY:
        raise RuntimeError("مفتاح CurseForge API غير مضاف. راجع ملف README.")
    params = {
        "gameId": MINECRAFT_GAME_ID,
        "searchFilter": query,
        "pageSize": page_size,
        "sortField": 2,
        "sortOrder": "desc",
    }
    response = requests.get(
        CF_SEARCH_URL,
        headers={"x-api-key": CURSEFORGE_API_KEY, "Accept": "application/json"},
        params=params,
        timeout=20,
    )
    response.raise_for_status()
    payload = response.json()
    return payload.get("data", [])

def project_caption(mod: dict) -> str:
    name = mod.get("name") or "إضافة ماينكرافت"
    summary = mod.get("summary") or "إضافة لماينكرافت. افتح صفحة المشروع لمعرفة التفاصيل والإصدارات المدعومة."
    url = mod.get("links", {}).get("websiteUrl") or ""
    return (
        f"🟫 <b>{clean(name)}</b>\n\n"
        f"🌏 <b>معلومات الإضافة</b>\n"
        f"✨ {clean(summary)}\n\n"
        f"🔗 <a href=\"{html.escape(url, quote=True)}\">صفحة الإضافة على CurseForge</a>\n\n"
        "من الادمن @OO0sy"
    )

def mod_keyboard(mod_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✏️ تعديل المنشور", callback_data=f"edit:{mod_id}")],
        [InlineKeyboardButton("📣 نشر بالقناة", callback_data=f"publish:{mod_id}")],
        [InlineKeyboardButton("🔗 فتح CurseForge", url=DRAFTS[mod_id]["url"])],
    ])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "هلا بيك في SormoBot 🟫\n\n"
        "أرسل اسم إضافة ماينكرافت للبحث عنها، أو استخدم:\n"
        "/search اسم الإضافة\n"
        "/random لإظهار إضافة عشوائية من نتائج CurseForge\n\n"
        "تنبيه: نتائج CurseForge قد تتضمن مشاريع Java؛ تحقق من دعم Bedrock داخل صفحة المشروع قبل النشر."
    )
    if is_admin(update):
        text += "\n\nأنت المدير. بعد اختيار إضافة تگدر تعدّل المنشور وتنشره بقناتك."
    await update.effective_message.reply_text(text)

async def search_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = " ".join(context.args).strip()
    if not query:
        await update.effective_message.reply_text("اكتب اسم الإضافة بعد الأمر، مثل:\n/search furniture")
        return
    await do_search(update, query)

async def do_search(update: Update, query: str):
    try:
        mods = cf_search(query, 10)
    except Exception as exc:
        log.exception("CurseForge search failed")
        await update.effective_message.reply_text(
            "ما كدرت أجيب النتائج من CurseForge.\n"
            "تأكد من إضافة CURSEFORGE_API_KEY وصحة إعدادات الاستضافة، وبعدها جرّب مرة ثانية."
        )
        return
    if not mods:
        await update.effective_message.reply_text("ما لقيت نتائج لهذا الاسم. جرّب كلمة إنجليزية أقصر.")
        return
    for mod in mods[:8]:
        mod_id = int(mod["id"])
        url = (mod.get("links") or {}).get("websiteUrl") or f"https://www.curseforge.com/minecraft/mc-mods/{mod_id}"
        DRAFTS[mod_id] = {
            "name": mod.get("name") or "Minecraft project",
            "summary": mod.get("summary") or "",
            "url": url,
            "logo": ((mod.get("logo") or {}).get("url") or ""),
            "caption": project_caption({**mod, "links": {**(mod.get("links") or {}), "websiteUrl": url}}),
        }
        message = f"<b>{clean(DRAFTS[mod_id]['name'])}</b>\n{clean(DRAFTS[mod_id]['summary'][:500])}"
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("عرض / تجهيز المنشور", callback_data=f"draft:{mod_id}")],
            [InlineKeyboardButton("فتح صفحة المشروع", url=url)],
        ])
        logo = DRAFTS[mod_id]["logo"]
        try:
            if logo:
                await update.effective_message.reply_photo(
                    photo=logo, caption=message, parse_mode=ParseMode.HTML, reply_markup=keyboard
                )
            else:
                await update.effective_message.reply_text(
                    message, parse_mode=ParseMode.HTML, reply_markup=keyboard, disable_web_page_preview=True
                )
        except Exception:
            await update.effective_message.reply_text(
                message, parse_mode=ParseMode.HTML, reply_markup=keyboard, disable_web_page_preview=True
            )

async def random_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        mods = cf_search("", 50)
    except Exception:
        await update.effective_message.reply_text(
            "تعذّر جلب النتائج. تأكد من إعداد CURSEFORGE_API_KEY في الاستضافة."
        )
        return
    if not mods:
        await update.effective_message.reply_text("ما وصلتني نتائج من CurseForge.")
        return
    chosen = random.choice(mods)
    # Reuse the regular search display path with the chosen project's name.
    await do_search(update, chosen.get("name") or "")

async def text_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return
    if is_admin(update) and update.effective_user.id in WAITING_FOR_EDIT:
        # Find the most recent draft for this admin and update its caption.
        WAITING_FOR_EDIT.discard(update.effective_user.id)
        mod_id = context.user_data.get("editing_mod_id")
        if not mod_id or mod_id not in DRAFTS:
            await update.message.reply_text("انتهت مسودة التعديل. ابحث عن الإضافة من جديد.")
            return
        DRAFTS[mod_id]["caption"] = html.escape(update.message.text)
        await update.message.reply_text(
            "تم حفظ النص المعدّل كنص عادي. اضغط نشر بالقناة من بطاقة الإضافة.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📣 نشر بالقناة", callback_data=f"publish:{mod_id}")]
            ])
        )
        return
    await do_search(update, update.message.text.strip())

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data or ""
    action, _, raw_id = data.partition(":")
    try:
        mod_id = int(raw_id)
    except ValueError:
        return
    if mod_id not in DRAFTS:
        await query.message.reply_text("انتهت صلاحية هذه المسودة. ابحث عن الإضافة من جديد.")
        return
    if action == "draft":
        if not is_admin(update):
            await query.message.reply_text("ميزة تجهيز المنشور مخصصة لمدير البوت.")
            return
        draft = DRAFTS[mod_id]
        await query.message.reply_text(
            draft["caption"], parse_mode=ParseMode.HTML,
            reply_markup=mod_keyboard(mod_id), disable_web_page_preview=True
        )
    elif action == "edit":
        if not is_admin(update):
            await query.message.reply_text("التعديل مخصص لمدير البوت.")
            return
        context.user_data["editing_mod_id"] = mod_id
        WAITING_FOR_EDIT.add(update.effective_user.id)
        await query.message.reply_text("أرسل النص الكامل الجديد للمنشور برسالة واحدة.")
    elif action == "publish":
        if not is_admin(update):
            await query.message.reply_text("النشر مخصص لمدير البوت.")
            return
        if not CHANNEL_ID:
            await query.message.reply_text("أضف CHANNEL_ID إلى متغيرات الاستضافة أولاً. راجع README.")
            return
        draft = DRAFTS[mod_id]
        try:
            if draft.get("logo"):
                await context.bot.send_photo(
                    chat_id=CHANNEL_ID, photo=draft["logo"], caption=draft["caption"],
                    parse_mode=ParseMode.HTML
                )
            else:
                await context.bot.send_message(
                    chat_id=CHANNEL_ID, text=draft["caption"],
                    parse_mode=ParseMode.HTML, disable_web_page_preview=True
                )
            await query.message.reply_text("تم إرسال المنشور إلى القناة.")
        except Exception as exc:
            log.exception("Channel publish failed")
            await query.message.reply_text(
                "فشل النشر. تأكد أن البوت مشرف بالقناة ولديه صلاحية نشر الرسائل، وأن CHANNEL_ID صحيح."
            )

async def post_init(app: Application):
    # Helpful startup log; do not print secrets.
    log.info("SormoBot started")

def main():
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("search", search_command))
    app.add_handler(CommandHandler("random", random_command))
    app.add_handler(CallbackQueryHandler(callback_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_search))
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
